
/**
 * Trabalho de implementação II-2018.1 UFSC

 *Título do trabalho : Pesquisa de ManPages
 
 * Cursos: Ciências da Computação & Sistemas de informação

 * INE5408 - Estruturas de Dados
 
 * Trabalho de Implementação 2 - 
 *
 * Alunos: Kuassi Dodji Franck &  
 *
 * Niveau.h
 */

#ifndef NIVEAU_H
#define NIVEAU_H
/** 
*Ce struct est utilisé pr organiser les indices dans l'abre pour qu'elles soit retirées par niveau
*
*
*/

struct Niveau{

    char comando[100];

    int posicao;
    //Define os operadores para poder usar na Avl

    
    Niveau() {
        comando[0] = '\0';
        for(int i=1; i<100; i++) {
            comando[i] = ' ';
        }
        posicao = 0;
    }

    bool operator==(const Niveau& Index) const {
        if (strcmp(comando, Index.comando) == 0) return true;
        return false;
    }

    bool operator<(const Niveau& Index) const {
        if (strcmp(comando, Index.comando) < 0) return true;
        return false;
    }

    bool operator>(const Niveau& Index) const {
        if (strcmp(comando, Index.comando) > 0) return true;
        return false;
    }
};

#endif /* NIVEAU_H */
