/**
 * Trabalho de implementação II-2018.1 UFSC

 *Título do trabalho : Pesquisa de ManPages
 
 * Cursos: Ciências da Computação & Sistemas de informação

 * INE5408 - Estruturas de Dados
 
 * Trabalho de Implementação 2 - 
 *
 * Alunos: Kuassi Dodji Franck &  
 *
 * Mot.h
 */

#ifndef MOT_H
#define MOT_H

#include <deque>
using std::deque;

/**
 * Struct utilizada para conter as palavras que estão contidas no arquivo
 */
struct Mot {
    
    char mot[100];
    deque<int>  Potition;

    Mot() {
        mot[0] = '\0';
        for (int i=1; i<100; i++) {
            mot[i] = ' ';
        }
    }

    Mot(char* p, int t) {

        for (int i=1; i<100; i++) {
            mot[i] = ' ';
        }

        strcpy(mot, p);

        Potition.push_back(t);

    }

    bool operator==(const Mot& palavra) const {

        if (strcmp(mot, palavra.mot) == 0) return true;


        return false;
    }

    bool operator<(const Mot& palavra) const {

        if (strcmp(mot, palavra.mot) < 0) return true;

        return false;
    }

    bool operator>(const Mot& palavra) const {

        if (strcmp(mot, palavra.mot) > 0) return true;
        return false;
    }
};

#endif /* Mot_H */
